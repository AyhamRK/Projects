
 # Project Overview
This assignment aims to give students hands-on experience with Generative AI and Large Language Models, focusing on their applications, architecture, and real-world usage using the Hugging Face ecosystem.  
Throughout the project, you will work with tasks such as text summarization, question answering, and
story generation, supported by real datasets and pretrained transformer models.



# Repository Contents
|          File         |               Description                                         |
| `summarization_qa.py` | Summarizes an article using BART and performs QA with DistilBERT. |
| `text_generation.py` | Generates stories using GPT-2 based on user prompts. |
| `my_dataset.txt` | Custom dataset used for fine-tuning the model distilgpt2. |
| `summarization_data.txt` | Input article for summarization/QA tasks. |
| `fine_tuning.ipynb` | Notebook used for fine-tuning distilgpt2 model. |



# Technologies & Models Used
- Python 3.10+
- Hugging Face Transformers
  - `facebook/bart-large-cnn` (Summarization)
  - `distilbert-base-cased-distilled-squad` (Question Answering)
  - `gpt2` (Text Generation)
- Google Colab 
- PyTorch backend



# Installation
# Clone the repository
```bash
git clone https://github.com/yourusername/yourrepo.git
cd yourrepo
```

# Install dependencies
```bash
pip install transformers torch datasets
```



# How to Run the Scripts

# 1. Text Summarization + QA
This script loads an article, summarizes it, and then lets you ask questions.

```bash
python summarization_qa.py
```

# 2. Text Generation
Generates 3 different stories using GPT-2 based on your prompts.

```bash
python text_generation.py
```



# Project Structure
```
summarization_qa.py
text_generation.py
fine_tuning.ipynb
my_dataset.txt
summarization_data.txt
README.md
```



# How It Works

# Summarization
Uses a sequence-to-sequence encoder decoder model (BART) to compress the text while preserving meaning.

# Question Answering
DistilBERT extracts answers from the original article context.

# Text Generation
GPT-2 predicts the next tokens based on a user-provided prompt.





# Credits
All model checkpoints and pipelines are provided by Hugging Face.
